import os
import shutil

folder = os.path.dirname(os.path.abspath(__file__))

# Ordner erfragen und alle Dateien daraus in den aktuellen Ordner kopieren
src = input("Pfad zum Quellordner: ").strip().strip('"')
for name in os.listdir(src):
    src_file = os.path.join(src, name)
    if os.path.isfile(src_file):
        shutil.copy2(src_file, os.path.join(folder, name))
        print("kopiert: " + name)

# Zeile zu table.csv hinzufuegen, sofern noch nicht vorhanden
csv_path = os.path.join(folder, "table.csv")

line = "FileStore; N; rzMandant varchar(35); FileDir varchar(70); FileName varchar(100); ; Microsoft JDBC Driver 12.2 for SQL Server; ;"

with open(csv_path, "r", encoding="utf-8") as f:
    lines = [l.rstrip("\n").rstrip("\r") for l in f]

if line in lines:
    print("Zeile bereits vorhanden, nichts geaendert.")
else:
    with open(csv_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print("Zeile angefuegt.")

# Spaltenzeile zu column.csv hinzufuegen, sofern noch nicht vorhanden
col_path = os.path.join(folder, "column.csv")

col_line = "FileStore; angelegt decimal(18) null; angelegtdurch varchar(35) null; geaendert decimal(18) null; geaendertdurch varchar(35) null; Dirty int null; rzMandant varchar(35); rzGruppeMandant varchar(35) null; FileDir varchar(70); FileName varchar(100); FileType decimal(19) null; FileBezeichnung varchar(255) null; FileSize decimal(19) null; FileDate datetime2 null; FileData image null; PrintServerID varchar(10) null; ;"

with open(col_path, "r", encoding="utf-8") as f:
    col_lines = [l.rstrip("\n").rstrip("\r") for l in f]

if col_line in col_lines:
    print("column.csv: Zeile bereits vorhanden, nichts geaendert.")
else:
    with open(col_path, "a", encoding="utf-8") as f:
        f.write(col_line + "\n")
    print("column.csv: Zeile angefuegt.")

# Association-Zeilen aus filestoreassocs.csv an association.csv anhaengen,
# jeweils nur, sofern noch nicht vorhanden (ohne '#'-Kopfzeile und Leerzeilen)
assoc_src = os.path.join(folder, "filestoreassocs.csv")
assoc_target = os.path.join(folder, "association.csv")

with open(assoc_target, "r", encoding="utf-8") as f:
    existing = set(l.rstrip("\n").rstrip("\r") for l in f)

added = 0
with open(assoc_src, "r", encoding="utf-8") as f:
    new_lines = [l.rstrip("\n").rstrip("\r") for l in f]

with open(assoc_target, "a", encoding="utf-8") as f:
    for al in new_lines:
        if al.strip() == "" or al.strip() == "#":
            continue
        if al in existing:
            continue
        f.write(al + "\n")
        existing.add(al)
        added += 1

print(str(added) + " Association-Zeile(n) angefuegt.")

input("Fertig. Zum Beenden Eingabetaste druecken...")
